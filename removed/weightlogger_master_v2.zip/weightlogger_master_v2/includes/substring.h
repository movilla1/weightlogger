void substring(byte src[], byte dst[], int start_pos, int length);
void short_concat(byte dest[], byte src[]);
