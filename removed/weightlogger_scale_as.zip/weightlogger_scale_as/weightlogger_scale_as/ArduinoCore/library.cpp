/*
 * ArduinoCore.cpp
 *
 * Created: 12-Dec-18 11:56:37 PM
 * Author : movil
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

