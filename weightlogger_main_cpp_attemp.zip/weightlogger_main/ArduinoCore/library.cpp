/*
 * ArduinoCore.cpp
 *
 * Created: 09-Dec-18 7:23:25 PM
 * Author : movil
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

