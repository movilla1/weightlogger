void substring(char src[], char dst[], int start_pos, int length);
