void hex_string_to_byte_array(char *src, char *out_array, char start, char end);
